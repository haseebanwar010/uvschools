<?php include (APPPATH . 'views/landing_page/landing_header.php'); ?>
<div class="container text-center" >

    
<br><br><br><br><br><br><br><br><br><br>
   <h1>Pricing for UVSchools is coming soon</h1>


</div>
<br>
                
</div>
    <?php include (APPPATH . 'views/landing_page/landing_footer.php'); ?>

