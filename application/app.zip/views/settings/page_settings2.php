<?php include(APPPATH . "views/inc/header.php"); ?>
<?php include(APPPATH . "views/inc/menu.php"); ?>
<?php include(APPPATH . "views/inc/sidebar.php"); ?>

<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid" style="margin-top: 35px;">
        <div class="row" style="margin: -25px; padding:0; bottom: 0;">
        	<div class="col-md-12 p-0">
            	<iframe style="width: 100%; min-height: 615px; max-height: 715px; border-radius: 0px; border: none;" src="<?php echo site_url('settings/page_settings'); ?>"></iframe>
        	</div>
        </div>
    </div>
<?php include(APPPATH . "views/inc/footer.php"); ?>