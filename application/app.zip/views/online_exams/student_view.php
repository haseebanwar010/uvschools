<?php include(APPPATH . "views/inc/header.php"); ?>
<?php include(APPPATH . "views/inc/menu.php"); ?>
<?php include(APPPATH . "views/inc/sidebar.php"); ?>
<div>
    <!-- Page Content -->
    <div id="page-wrapper" ng-controller="onlineExamsController" ng-init="initExamsForStudent();">
        <div class="container-fluid">
            <div class="row bg-title">
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <h4 class="page-title">Online Exams</h4>
                </div>
                <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                    <ol class="breadcrumb">
                        <li><a href="#"><?= lang('crumb_dashboard') ?></a></li>
                        <li><a href="#">Online Exams</a></li>
                        <li class="active">Student</li>
                    </ol>
                </div>
            </div>
            <!-- /.row -->
            <div class="hint">help_online_exams_student</div>
            <!-- Page Content start here -->
            <!--.row-->
            <div class="row">
                <?php if($this->session->flashdata("success_message") != null) { ?>
                    <div class="col-md-12">
                        <div class="alert alert-success"><?php echo $this->session->flashdata("success_message"); ?></div>
                    </div>
                <?php } ?>

                <?php if($this->session->flashdata("published_message") != null) { ?>
                    <div class="col-md-12">
                        <div class="alert alert-danger"><?php echo $this->session->flashdata("published_message"); ?></div>
                    </div>
                <?php } ?>

                <?php if($this->session->flashdata("submitted_message") != null) { ?>
                    <div class="col-md-12">
                        <div class="alert alert-danger"><?php echo $this->session->flashdata("submitted_message"); ?></div>
                    </div>
                <?php } ?>

                <?php if($this->session->flashdata("paper_message") != null) { ?>
                    <div class="col-md-12">
                        <div class="alert alert-danger"><?php echo $this->session->flashdata("paper_message"); ?></div>
                    </div>
                <?php } ?>
                
                <div class="col-md-12">
                    <div class="white-box">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <tr style="background-color: #e3e3e3;">
                                    <th class="text-center"><span class="text-muted">#</span></th>
                                    <th>Subject / Paper</th>
                                    <th>Exam Type</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Number of Questions</th>
                                    <th>Duration</th>
                                    <th>Attempts</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                <?php if(count($exams) > 0) {
                                   $index=1;
                                   foreach($exams as $e) { ?>
                                    <tr class="text-center">
                                        <td class="text-center"><span class="text-muted"><?php echo $index++; ?></span></td>
                                        <td><?php echo $e->subject_name ." / ". $e->paper_name;  ?></td>
                                        <td><?php echo $e->title;  ?></td>
                                        <td><?php echo $e->start_date;  ?></td>
                                        <td><?php echo $e->end_date;  ?></td>
                                        <td><?php echo $e->number_of_questions;  ?></td>
                                        <td><?php echo $e->duration_in_minutes;  ?></td>
                                        <td><?php echo $e->attempts;  ?></td>
                                        <td>
                                            <?php if(date("Y-m-d") >= $e->start_date && date("Y-m-d") <= $e->end_date) { ?>
                                                <span class="text-success">Open</span>
                                                <!-- <img src="assets/images/new-icon-gif-3.jpg" height="15px" /> -->
                                            <?php } else { ?>
                                                <span class="text-danger">Closed</span>
                                            <?php } ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if(!(date("Y-m-d") >= $e->start_date && date("Y-m-d") <= $e->end_date)){ if($e->exam_submited) { ?>
                                                <span class="text-success">Exam Submitted</span>
                                            <?php }else {  ?>
                                                <span class="text-danger">Exam not submitted</span>
                                            <?php }}else if(!$e->exam_submited) { ?>
                                                <a href="online_exams/start_exam/<?php echo $e->exam_id; ?>/<?php echo $e->id; ?>" class="btn btn-sm btn-primary">Start Exam</a>
                                            <?php } else { ?>
                                                <span class="text-success">Exam Submitted</span>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php } } else { ?>
                                    <tr>
                                        <td colspan="9"><span class="text-danger">No online exam found!</span></td>
                                    </tr>
                                <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
                
            <!--./row-->
            <!--page content end here-->
        </div>
    </div>
    <!-- /.container-fluid -->
<?php include(APPPATH . "views/inc/footer.php"); ?>