<?php include(APPPATH . "views/inc/header.php"); ?>
<?php include(APPPATH . "views/inc/menu.php"); ?>
<?php include(APPPATH . "views/inc/sidebar.php"); ?>






<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <?php echo $output; ?>
        </div>	
    </div>
</div>


<?php include(APPPATH . "views/inc/footer.php"); ?>

