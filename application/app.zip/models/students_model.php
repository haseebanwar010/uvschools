<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Students_model extends CI_Model {


    function __construct() {
        parent::__construct();
    }
    public function getStudentByID($id){
        $school_id = $this->session->userdata("userdata")["sh_id"];
        $ci = $this->db;
        $ci->select('students_'.$school_id.'.*,classes.name as classname,batches.name as batchname,a.country_name,b.country_name as nationality,s.group_name,d.name as discount')
            ->select('date_format(sh_students_'.$school_id.'.dob,"%d/%m/%Y") as dobn' ,false)
            ->select('date_format(sh_students_'.$school_id.'.joining_date,"%d/%m/%Y") as adm_date' ,false);
        $ci->from('students_'.$school_id.'');
        $ci->join('classes','classes.id = students_'.$school_id.'.class_id')->join('batches','batches.id=students_'.$school_id.'.batch_id');
        $ci->join('sh_countries a','a.id = students_'.$school_id.'.country','left');
        $ci->join('sh_countries b','b.id = students_'.$school_id.'.nationality','left');
        $ci->join('sh_subject_groups s','s.id = students_'.$school_id.'.subject_group_id','left');
        $ci->join('sh_fee_discount d','d.id = students_'.$school_id.'.discount_id','left');

        $ci->where('students_'.$school_id.'.deleted_at', 0)->where('students_'.$school_id.'.id', $id);
        $query =  $ci->get();
        return $query->row();
    }
    
    public function getSpecificStudentForEdit($student_id){
        $school_id = $this->session->userdata("userdata")["sh_id"];
        $query = "select 
            u.id as student_id, 
            u.avatar as image2,
            u.religion as religion,
            u.name as firstname,
            u.gender as gender,
            u.dob as dob,
            u.ic_number,
            u.blood as blood,
            u.birthplace as birthPlace,
            u.nationality as nationality,
            u.language as language,
            u.email as email,
            u.contact as phone,
            u.country as country,
            u.city as city,
            u.address as address,
            u.class_id as course,
            u.batch_id as batch,
            u.rollno as rollno,
            u.discount_id as discount_id,
            u.joining_date as adm_date,
            u.subject_group_id as group_id,
            uu.id as parentId,
            uu.avatar as image3,
            uu.name as pName,
            uu.gender as pGender,
            uu.dob as pDob,
            uu.occupation as pOccupation,
            uu.income as pIncome,
            uu.email as pEmail,
            uu.contact as pPhone,
            uu.address as pStreet,
            uu.ic_number as pIdNumber,
            uu.country as pCountry,
            uu.city as pCity,
            sg.relation as pRelation,
            sg.id as student_guardian_id,
            sg.deleted_at
            from sh_students_".$school_id." u 
            left join sh_student_guardians sg ON sg.student_id=u.id 
            left join sh_users uu ON sg.guardian_id=uu.id 
            where u.id=" . $student_id . ";";
        $res = $this->db->query($query);
        return $res->row();
    }
    
    public function getAllStudents($where){
        $school_id = $this->session->userdata("userdata")["sh_id"];
        $sql_old = "Select u.*,sg.group_name,g.guardian_id,uu.name as father_name,c.name as class_name, b.name as batch_name, group_concat(t.name) as teacher_name from "
        . "sh_students_".$school_id." u "
        . "inner join sh_classes c on u.class_id=c.id "
        . "inner join sh_batches b on u.batch_id=b.id "
        . "inner join sh_users t on find_in_set(t.id, b.teacher_id) "
        . "left join sh_subject_groups sg on u.subject_group_id = sg.id "
        . "LEFT JOIN sh_student_guardians g ON u.id=g.student_id and g.deleted_at is null "
        . "LEFT JOIN sh_users uu On uu.id=g.guardian_id "
        . "Where u.academic_year_id = ".$this->session->userdata("userdata")["academic_year"]." and ".$where." group by u.id order by u.name";
        
        
        
        $sql = "Select 
            u.*,
            sg.group_name,
            g.guardian_id,
            uu.name as father_name,
            c.name as class_name, 
            b.name as batch_name, 
            uuu.name as teacher_name 
            FROM
            sh_users u
            LEFT JOIN sh_subject_groups sg on u.subject_group_id = sg.id 
            LEFT JOIN sh_student_guardians g ON u.id=g.student_id and g.deleted_at is null 
            LEFT JOIN sh_users uu On uu.id=g.guardian_id 
            LEFT JOIN sh_student_class_relation rl ON u.id=rl.student_id 
            INNER JOIN sh_classes c ON rl.class_id=c.id
            INNER JOIN sh_batches b ON rl.batch_id=b.id
            INNER JOIN sh_users uuu ON uuu.id=b.teacher_id
            WHERE ". $where ." order by u.name";
        
        $query = $this->db->query($sql_old);
        return $query->result();
    }
}